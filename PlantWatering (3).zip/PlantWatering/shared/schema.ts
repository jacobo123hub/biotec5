import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Plant schema
export const plants = pgTable("plants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  waterQuantity: integer("water_quantity").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const insertPlantSchema = createInsertSchema(plants).pick({
  name: true,
  waterQuantity: true,
  imageUrl: true,
});

export type InsertPlant = z.infer<typeof insertPlantSchema>;
export type Plant = typeof plants.$inferSelect;

// Watering schedule schema
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  hour: integer("hour").notNull(),
  minute: integer("minute").notNull(),
  ampm: text("ampm").notNull(),
  days: text("days").array().notNull(),
  isActive: boolean("is_active").notNull().default(true),
  plantQuantities: json("plant_quantities").$type<{plantId: number, quantity: number}[]>().notNull(),
});

export const insertScheduleSchema = createInsertSchema(schedules).pick({
  name: true,
  hour: true,
  minute: true,
  ampm: true,
  days: true,
  isActive: true,
  plantQuantities: true,
});

export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

// Activity log schema
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'watered', 'warning', etc.
  plantId: integer("plant_id"),
  scheduleName: text("schedule_name"),
  quantity: integer("quantity"),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  type: true,
  plantId: true,
  scheduleName: true,
  quantity: true,
  message: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Microcontroller schema
export const microcontrollers = pgTable("microcontrollers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("offline"), // 'online', 'offline', 'error'
  ipAddress: text("ip_address"),
  port: integer("port"),
  isAutomatic: boolean("is_automatic").notNull().default(false),
  lastConnection: timestamp("last_connection"),
});

export const insertMicrocontrollerSchema = createInsertSchema(microcontrollers).pick({
  name: true,
  status: true,
  ipAddress: true,
  port: true,
  isAutomatic: true,
  lastConnection: true,
});

export type InsertMicrocontroller = z.infer<typeof insertMicrocontrollerSchema>;
export type Microcontroller = typeof microcontrollers.$inferSelect;

// User schema - kept from original
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Sensor data schema
export const sensorData = pgTable("sensor_data", {
  id: serial("id").primaryKey(),
  microcontrollerId: integer("microcontroller_id").notNull(),
  humidity: integer("humidity").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertSensorDataSchema = createInsertSchema(sensorData).pick({
  microcontrollerId: true,
  humidity: true,
});

// Plant catalog schema
export const plantCatalog = pgTable("plant_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  minHumidity: integer("min_humidity").notNull(),
  maxHumidity: integer("max_humidity").notNull(),
  lightConditions: text("light_conditions").notNull(),
  temperature: text("temperature").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const insertPlantCatalogSchema = createInsertSchema(plantCatalog);

export type InsertSensorData = z.infer<typeof insertSensorDataSchema>;
export type SensorData = typeof sensorData.$inferSelect;
export type InsertPlantCatalog = z.infer<typeof insertPlantCatalogSchema>;
export type PlantCatalog = typeof plantCatalog.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
