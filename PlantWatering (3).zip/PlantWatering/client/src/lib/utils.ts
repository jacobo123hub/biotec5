import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTime(hour: number, minute: number, ampm: 'AM' | 'PM'): string {
  const formattedHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  const formattedMinute = minute.toString().padStart(2, '0');
  return `${formattedHour}:${formattedMinute} ${ampm}`;
}

export const weekdays = [
  { value: "mon", label: "Mon" },
  { value: "tue", label: "Tue" },
  { value: "wed", label: "Wed" },
  { value: "thu", label: "Thu" },
  { value: "fri", label: "Fri" },
  { value: "sat", label: "Sat" },
  { value: "sun", label: "Sun" }
];

export function formatDays(days: string[]): string {
  if (days.length === 7) return "Every day";
  if (days.length === 0) return "No days selected";
  
  return days.map(day => {
    const weekday = weekdays.find(w => w.value === day);
    return weekday?.label || day;
  }).join(", ");
}

export function calculateNextWatering(schedules: any[]): string {
  if (schedules.length === 0) return "No schedules";

  const now = new Date();
  const currentDay = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"][now.getDay()];
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  
  // Filter schedules to only include active ones
  const activeSchedules = schedules.filter(schedule => schedule.isActive);
  if (activeSchedules.length === 0) return "No active schedules";

  // Find the next schedule
  let nextSchedule: any = null;
  let minTimeUntil = Infinity;

  for (const schedule of activeSchedules) {
    // Check if the schedule is for today or a future day
    const scheduleDays = schedule.days;
    let dayIndex = scheduleDays.indexOf(currentDay);
    
    // If not found or already passed today's time
    if (dayIndex === -1 || 
        (dayIndex === 0 && (schedule.hour > 12 ? schedule.hour - 12 : schedule.hour) > currentHour) || 
        (dayIndex === 0 && (schedule.hour > 12 ? schedule.hour - 12 : schedule.hour) === currentHour && schedule.minute > currentMinute)) {
      // Find the next upcoming day
      for (let i = 0; i < scheduleDays.length; i++) {
        const day = scheduleDays[i];
        const dayOffset = (weekdays.findIndex(w => w.value === day) - now.getDay() + 7) % 7;
        
        let timeUntil = dayOffset * 24 * 60; // Days converted to minutes
        
        // If same day, calculate time difference
        if (dayOffset === 0) {
          const scheduleMinutes = schedule.hour * 60 + schedule.minute;
          const currentMinutes = currentHour * 60 + currentMinute;
          
          if (scheduleMinutes > currentMinutes) {
            timeUntil += (scheduleMinutes - currentMinutes);
          } else {
            timeUntil = 7 * 24 * 60 + (scheduleMinutes - currentMinutes); // Next week
          }
        } else {
          // Different day, add schedule time
          timeUntil += schedule.hour * 60 + schedule.minute;
        }
        
        if (timeUntil < minTimeUntil) {
          minTimeUntil = timeUntil;
          nextSchedule = schedule;
        }
      }
    }
  }

  if (!nextSchedule || minTimeUntil === Infinity) return "No upcoming schedule";

  // Format the time until next watering
  const hours = Math.floor(minTimeUntil / 60);
  const minutes = minTimeUntil % 60;
  
  if (hours === 0) {
    return `${minutes}m`;
  } else if (minutes === 0) {
    return `${hours}h`;
  } else {
    return `${hours}h ${minutes}m`;
  }
}

export function calculateWaterUsedToday(activities: any[]): string {
  const today = new Date();
  const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  
  const todayActivities = activities.filter(activity => {
    const activityDate = new Date(activity.timestamp);
    return activityDate >= startOfDay && activityDate <= today && activity.type === 'watered';
  });
  
  if (todayActivities.length === 0) return "0ml";
  
  const totalWater = todayActivities.reduce((sum, activity) => sum + activity.quantity, 0);
  
  if (totalWater >= 1000) {
    return `${(totalWater / 1000).toFixed(1)}L`;
  } else {
    return `${totalWater}ml`;
  }
}
