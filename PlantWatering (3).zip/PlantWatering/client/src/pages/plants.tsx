import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plant } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertPlantSchema } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { QuantityInput } from "@/components/ui/quantity-input";

const formSchema = insertPlantSchema.extend({
  // Add additional validation if needed
});

export default function Plants() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingPlant, setEditingPlant] = useState<Plant | null>(null);
  
  const { data: plants = [], isLoading } = useQuery<Plant[]>({
    queryKey: ["/api/plants"],
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      waterQuantity: 200,
      imageUrl: "https://images.unsplash.com/photo-1620127682229-33388276e540?w=300&h=200&fit=crop"
    },
  });
  
  const resetForm = () => {
    form.reset({
      name: "",
      waterQuantity: 200,
      imageUrl: "https://images.unsplash.com/photo-1620127682229-33388276e540?w=300&h=200&fit=crop"
    });
    setEditingPlant(null);
  };
  
  const openAddDialog = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };
  
  const openEditDialog = (plant: Plant) => {
    form.reset({
      name: plant.name,
      waterQuantity: plant.waterQuantity,
      imageUrl: plant.imageUrl
    });
    setEditingPlant(plant);
    setIsAddDialogOpen(true);
  };
  
  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setTimeout(resetForm, 300);
  };
  
  const createPlantMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const res = await apiRequest("POST", "/api/plants", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/plants"] });
      toast({
        title: "Success",
        description: "Plant added successfully.",
      });
      closeDialog();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add plant: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const updatePlantMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: z.infer<typeof formSchema> }) => {
      const res = await apiRequest("PUT", `/api/plants/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/plants"] });
      toast({
        title: "Success",
        description: "Plant updated successfully.",
      });
      closeDialog();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update plant: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const deletePlantMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/plants/${id}`, null);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/plants"] });
      toast({
        title: "Success",
        description: "Plant deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete plant: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const waterNowMutation = useMutation({
    mutationFn: async ({ plantId, quantity }: { plantId: number, quantity: number }) => {
      const res = await apiRequest("POST", "/api/water-now", { plantId, quantity });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Watering Completed",
        description: data.message,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to water plant: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    if (editingPlant) {
      updatePlantMutation.mutate({ id: editingPlant.id, data });
    } else {
      createPlantMutation.mutate(data);
    }
  };
  
  const handleImagePlaceholderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // To avoid using actual image upload logic, we'll just let the user input a URL
    form.setValue("imageUrl", e.target.value);
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-medium">My Plants</h2>
        <Button 
          onClick={openAddDialog}
          className="bg-primary text-white flex items-center"
        >
          <span className="material-icons text-sm mr-1">add</span> Add Plant
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center p-12">
          <span className="material-icons animate-spin mr-2">refresh</span>
          <span>Loading plants...</span>
        </div>
      ) : plants.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {plants.map(plant => (
            <Card key={plant.id} className="overflow-hidden">
              <div className="h-40 bg-gray-200 relative">
                <img 
                  src={plant.imageUrl} 
                  alt={plant.name} 
                  className="w-full h-full object-cover" 
                />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="absolute top-2 right-2 p-2 h-auto rounded-full bg-white bg-opacity-90"
                    >
                      <span className="material-icons text-gray-700">more_vert</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={() => openEditDialog(plant)}>
                      <span className="material-icons text-sm mr-2">edit</span>
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-red-600"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${plant.name}?`)) {
                          deletePlantMutation.mutate(plant.id);
                        }
                      }}
                    >
                      <span className="material-icons text-sm mr-2">delete</span>
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-lg">{plant.name}</h3>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="text-xs text-primary flex items-center"
                    onClick={() => waterNowMutation.mutate({ 
                      plantId: plant.id, 
                      quantity: plant.waterQuantity 
                    })}
                    disabled={waterNowMutation.isPending}
                  >
                    <span className="material-icons text-xs mr-1">water_drop</span>
                    Water Now
                  </Button>
                </div>
                <div className="flex items-center text-gray-500 text-sm">
                  <span className="water-drop"></span>
                  <span className="mr-1">Needs</span>
                  <span className="font-medium">{plant.waterQuantity}ml</span>
                  <span className="ml-1">of water</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <p className="text-gray-500 mb-4">No plants found</p>
          <Button 
            onClick={openAddDialog}
            className="bg-primary text-white inline-flex items-center"
          >
            <span className="material-icons text-sm mr-1">add</span> Add Your First Plant
          </Button>
        </div>
      )}
      
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingPlant ? "Edit Plant" : "Add New Plant"}</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Plant Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Monstera" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="waterQuantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Water Quantity</FormLabel>
                    <FormControl>
                      <QuantityInput
                        value={field.value}
                        onChange={field.onChange}
                        min={10}
                        max={500}
                        step={10}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL (optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter image URL" 
                        onChange={handleImagePlaceholderChange} 
                        value={field.value} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-end space-x-3 pt-2">
                <Button variant="outline" type="button" onClick={closeDialog}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createPlantMutation.isPending || updatePlantMutation.isPending}
                >
                  {createPlantMutation.isPending || updatePlantMutation.isPending ? (
                    <>
                      <span className="material-icons animate-spin mr-2">refresh</span>
                      Saving...
                    </>
                  ) : editingPlant ? "Update Plant" : "Add Plant"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
