import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Schedule, Plant } from "@shared/schema";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ScheduleForm from "@/components/schedules/schedule-form";
import { formatTime, formatDays } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function Schedules() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
  
  const { data: schedules = [], isLoading } = useQuery<Schedule[]>({
    queryKey: ["/api/schedules"],
  });
  
  const { data: plants = [] } = useQuery<Plant[]>({
    queryKey: ["/api/plants"],
  });
  
  const toggleScheduleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const res = await apiRequest("PUT", `/api/schedules/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Success",
        description: "Schedule status updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update schedule: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const deleteScheduleMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/schedules/${id}`, null);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Success",
        description: "Schedule deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete schedule: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const handleToggleSchedule = (id: number, isActive: boolean) => {
    toggleScheduleMutation.mutate({ id, isActive: !isActive });
  };
  
  const getPlantNameById = (id: number) => {
    const plant = plants.find(p => p.id === id);
    return plant?.name || "Unknown Plant";
  };
  
  const openEditDialog = (schedule: Schedule) => {
    setEditingSchedule(schedule);
    setIsAddDialogOpen(true);
  };
  
  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setTimeout(() => setEditingSchedule(null), 300);
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-medium">Watering Schedules</h2>
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="bg-primary text-white flex items-center"
        >
          <span className="material-icons text-sm mr-1">add</span> New Schedule
        </Button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center p-12">
          <span className="material-icons animate-spin mr-2">refresh</span>
          <span>Loading schedules...</span>
        </div>
      ) : schedules.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {schedules.map(schedule => (
            <Card key={schedule.id} className={`border-l-4 ${schedule.isActive ? 'border-l-primary' : 'border-l-gray-300'}`}>
              <CardContent className="p-5">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="font-medium text-lg">{schedule.name}</h3>
                    <p className="text-sm text-gray-500">
                      {formatTime(schedule.hour, schedule.minute, schedule.ampm as 'AM' | 'PM')} • {formatDays(schedule.days)}
                    </p>
                  </div>
                  
                  <div className="flex items-center">
                    <Switch 
                      checked={schedule.isActive} 
                      onCheckedChange={() => handleToggleSchedule(schedule.id, schedule.isActive)}
                      className="mr-2"
                    />
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <span className="material-icons">more_vert</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => openEditDialog(schedule)}>
                          <span className="material-icons text-sm mr-2">edit</span>
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-red-600"
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete ${schedule.name}?`)) {
                              deleteScheduleMutation.mutate(schedule.id);
                            }
                          }}
                        >
                          <span className="material-icons text-sm mr-2">delete</span>
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Plants to water:</h4>
                  <div className="flex flex-wrap gap-2">
                    {schedule.plantQuantities.map(pq => (
                      <span 
                        key={pq.plantId} 
                        className="text-xs bg-primary bg-opacity-10 text-primary-dark px-2 py-1 rounded-full"
                      >
                        {getPlantNameById(pq.plantId)} ({pq.quantity}ml)
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="mt-4 text-right">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    schedule.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {schedule.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <p className="text-gray-500 mb-4">No schedules found</p>
          <Button 
            onClick={() => setIsAddDialogOpen(true)}
            className="bg-primary text-white inline-flex items-center"
          >
            <span className="material-icons text-sm mr-1">add</span> Create Your First Schedule
          </Button>
        </div>
      )}
      
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingSchedule ? "Edit Watering Schedule" : "Add New Watering Schedule"}</DialogTitle>
          </DialogHeader>
          <ScheduleForm 
            onComplete={closeDialog} 
            initialData={editingSchedule}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
