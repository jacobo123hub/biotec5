import Stats from "@/components/dashboard/stats";
import RecentActivity from "@/components/dashboard/recent-activity";
import ActiveSchedules from "@/components/dashboard/active-schedules";
import PlantsOverview from "@/components/dashboard/plants-overview";
import MicrocontrollerControl from "@/components/dashboard/microcontroller-control";
import WiFiSettings from "@/components/dashboard/wifi-settings";
import BluetoothController from "@/components/bluetooth/bluetooth-controller";

export default function Dashboard() {
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-8">
        <h2 className="text-2xl font-medium mb-4">Panel de Control</h2>
        
        <Stats />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <MicrocontrollerControl />
          <WiFiSettings />
          <BluetoothController />
        </div>
        
        <RecentActivity />
        <ActiveSchedules />
        <PlantsOverview />
      </div>
    </div>
  );
}
