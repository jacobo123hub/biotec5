import { useLocation, Link } from "wouter";

export default function MobileNav() {
  const [location] = useLocation();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around p-2 lg:hidden">
      <Link 
        href="/"
        className={`flex flex-col items-center py-2 ${location === "/" ? "text-primary" : "text-gray-500"}`}
      >
        <span className="material-icons">dashboard</span>
        <span className="text-xs mt-1">Dashboard</span>
      </Link>
      <Link 
        href="/plants"
        className={`flex flex-col items-center py-2 ${location === "/plants" ? "text-primary" : "text-gray-500"}`}
      >
        <span className="material-icons">grass</span>
        <span className="text-xs mt-1">Plants</span>
      </Link>
      <Link 
        href="/schedules"
        className={`flex flex-col items-center py-2 ${location === "/schedules" ? "text-primary" : "text-gray-500"}`}
      >
        <span className="material-icons">schedule</span>
        <span className="text-xs mt-1">Schedules</span>
      </Link>
      <Link 
        href="/history"
        className={`flex flex-col items-center py-2 ${location === "/history" ? "text-primary" : "text-gray-500"}`}
      >
        <span className="material-icons">history</span>
        <span className="text-xs mt-1">History</span>
      </Link>
    </nav>
  );
}
