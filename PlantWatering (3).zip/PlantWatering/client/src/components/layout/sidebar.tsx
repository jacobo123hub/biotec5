import { useLocation, Link } from "wouter";

export default function Sidebar() {
  const [location] = useLocation();
  
  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:bg-white lg:shadow-md lg:h-screen">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-primary">PlantCare</h1>
        <p className="text-gray-500 text-sm">Smart Watering System</p>
      </div>
      
      <nav className="flex-1 mt-6">
        <ul>
          <li className="mb-2">
            <Link 
              href="/"
              className={`flex items-center px-6 py-3 ${
                location === "/" 
                  ? "text-primary bg-primary bg-opacity-10" 
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="material-icons mr-3">dashboard</span>
              Dashboard
            </Link>
          </li>
          <li className="mb-2">
            <Link 
              href="/plants"
              className={`flex items-center px-6 py-3 ${
                location === "/plants" 
                  ? "text-primary bg-primary bg-opacity-10" 
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="material-icons mr-3">grass</span>
              My Plants
            </Link>
          </li>
          <li className="mb-2">
            <Link 
              href="/schedules"
              className={`flex items-center px-6 py-3 ${
                location === "/schedules" 
                  ? "text-primary bg-primary bg-opacity-10" 
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="material-icons mr-3">schedule</span>
              Schedules
            </Link>
          </li>
          <li className="mb-2">
            <Link 
              href="/history"
              className={`flex items-center px-6 py-3 ${
                location === "/history" 
                  ? "text-primary bg-primary bg-opacity-10" 
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="material-icons mr-3">history</span>
              History
            </Link>
          </li>
          <li className="mb-2">
            <Link 
              href="/settings"
              className={`flex items-center px-6 py-3 ${
                location === "/settings" 
                  ? "text-primary bg-primary bg-opacity-10" 
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <span className="material-icons mr-3">settings</span>
              Settings
            </Link>
          </li>
        </ul>
      </nav>
      
      <div className="p-6 border-t border-gray-200">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full mr-3 bg-gray-200 flex items-center justify-center">
            <span className="material-icons text-gray-500">person</span>
          </div>
          <div>
            <p className="text-sm font-medium">Plant Enthusiast</p>
            <p className="text-xs text-gray-500">Local User</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
