import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Loader2, Bluetooth, Send, Power, Droplet } from "lucide-react";
import { QuantityInput } from "@/components/ui/quantity-input";

export default function BluetoothController() {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [deviceName, setDeviceName] = useState("ESP32_BT");
  const [humidity, setHumidity] = useState<number | null>(null);
  const [waterQuantity, setWaterQuantity] = useState(200);
  const [isPumpActive, setIsPumpActive] = useState(false);
  const [lastMessage, setLastMessage] = useState("");
  
  // Simulación de conexión Bluetooth (versión segura)
  const connectDevice = async () => {
    try {
      setIsConnecting(true);
      
      // Simular tiempo de conexión
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simular éxito de conexión
      setIsConnected(true);
      setHumidity(Math.floor(Math.random() * 40) + 20); // Valor entre 20-60%
      
      toast({
        title: "Conectado al dispositivo",
        description: "La conexión Bluetooth se ha establecido correctamente",
      });
      
      // Iniciar actualización periódica de datos
      startDataUpdates();
      
    } catch (error) {
      console.error('Error conectando por Bluetooth:', error);
      toast({
        variant: "destructive",
        title: "Error de conexión",
        description: "No se pudo conectar al dispositivo",
      });
    } finally {
      setIsConnecting(false);
    }
  };
  
  // Simulación de desconexión
  const disconnectDevice = async () => {
    try {
      setIsConnected(false);
      setHumidity(null);
      toast({
        title: "Dispositivo desconectado",
        description: "La conexión Bluetooth se ha cerrado",
      });
    } catch (error) {
      console.error('Error desconectando:', error);
    }
  };
  
  // Simulación de activación de bomba
  const startPump = async () => {
    if (!isConnected) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No hay conexión con el dispositivo",
      });
      return;
    }
    
    try {
      // Convertir mililitros a segundos (depende de tu bomba)
      const durationSeconds = Math.ceil(waterQuantity / 100);
      
      // Simular comando de bomba
      setIsPumpActive(true);
      const message = `Bomba activada para regar ${waterQuantity}ml`;
      setLastMessage(message);
      
      toast({
        title: "Comando enviado",
        description: `Activando bomba para dispensar ${waterQuantity}ml de agua`,
      });
      
      // Simular finalización después de X segundos
      setTimeout(() => {
        setIsPumpActive(false);
        const finishMessage = "Bomba detenida: riego completado";
        setLastMessage(finishMessage);
        
        // Simular cambio en humedad después del riego
        if (humidity !== null) {
          const newHumidity = Math.min(95, humidity + Math.floor(waterQuantity / 20));
          setHumidity(newHumidity);
        }
        
        toast({
          title: "Bomba detenida",
          description: "La bomba ha terminado de funcionar",
        });
      }, durationSeconds * 1000);
      
    } catch (error) {
      console.error('Error activando bomba:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo activar la bomba",
      });
    }
  };
  
  // Simulación de actualizaciones periódicas de datos
  const startDataUpdates = () => {
    const intervalId = setInterval(() => {
      if (isConnected && !isPumpActive) {
        // Simular fluctuación natural de humedad (reducción gradual)
        setHumidity(prevHumidity => {
          if (prevHumidity === null) return 45;
          return Math.max(10, prevHumidity - Math.floor(Math.random() * 2));
        });
      }
    }, 5000);
    
    return () => clearInterval(intervalId);
  };
  
  // Iniciar/detener actualizaciones según estado de conexión
  useEffect(() => {
    let intervalId: number | undefined;
    
    if (isConnected) {
      intervalId = window.setInterval(() => {
        if (!isPumpActive) {
          setHumidity(prevHumidity => {
            if (prevHumidity === null) return 45;
            return Math.max(10, prevHumidity - Math.floor(Math.random() * 2));
          });
        }
      }, 5000);
    }
    
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isConnected, isPumpActive]);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bluetooth className="mr-2 h-5 w-5" />
          Control Bluetooth
        </CardTitle>
        <CardDescription>
          Conecta y controla tu ESP32 directamente vía Bluetooth
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isConnected ? (
            <>
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-sm font-medium">Estado:</span>
                  <div className="flex items-center">
                    <div className="mr-2 h-3 w-3 rounded-full bg-green-500"></div>
                    <span>Conectado a {deviceName}</span>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={disconnectDevice}
                  className="ml-auto"
                >
                  <Power className="mr-2 h-4 w-4" />
                  Desconectar
                </Button>
              </div>
              
              {humidity !== null && (
                <div className="mt-4 rounded-lg bg-muted p-4">
                  <h4 className="mb-2 font-medium">Humedad del suelo</h4>
                  <div className="flex items-center">
                    <div className="relative h-2 w-full rounded-full bg-gray-200">
                      <div 
                        className="absolute h-2 rounded-full bg-blue-500" 
                        style={{ width: `${humidity}%` }}
                      ></div>
                    </div>
                    <span className="ml-2 text-sm font-medium">{humidity}%</span>
                  </div>
                </div>
              )}
              
              <div className="mt-6">
                <h4 className="mb-2 font-medium">Control de riego</h4>
                <div className="flex items-center space-x-4">
                  <QuantityInput
                    value={waterQuantity}
                    min={50}
                    max={1000}
                    step={50}
                    onChange={setWaterQuantity}
                    unit="ml"
                    className="w-40"
                  />
                  
                  <Button 
                    onClick={startPump} 
                    disabled={isPumpActive}
                    className="flex-1"
                  >
                    {isPumpActive ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Bomba activa...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Regar ahora
                      </>
                    )}
                  </Button>
                </div>
              </div>
              
              {lastMessage && (
                <div className="mt-4 text-xs text-muted-foreground">
                  <span className="font-semibold">Último mensaje:</span> {lastMessage}
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-8">
              <Bluetooth className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 text-lg font-medium">No conectado</h3>
              <p className="mb-4 text-center text-sm text-muted-foreground">
                Conecta tu ESP32 para controlar el riego de tus plantas mediante Bluetooth.
              </p>
              <Button 
                onClick={connectDevice} 
                disabled={isConnecting}
                className="w-full max-w-xs"
              >
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Conectando...
                  </>
                ) : (
                  <>
                    <Bluetooth className="mr-2 h-4 w-4" />
                    Conectar ESP32
                  </>
                )}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        <Droplet className="mr-1 h-3 w-3" />
        Asegúrate de tener agua suficiente en el tanque antes de activar la bomba.
      </CardFooter>
    </Card>
  );
}