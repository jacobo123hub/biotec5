import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { insertScheduleSchema } from "@shared/schema";
import { TimePicker } from "@/components/ui/time-picker";
import { DaySelector } from "@/components/ui/day-selector";
import { QuantityInput } from "@/components/ui/quantity-input";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ScheduleFormProps {
  onComplete: () => void;
  initialData?: any;
}

const formSchema = insertScheduleSchema.extend({
  selectedPlants: z.array(z.number()),
});

export default function ScheduleForm({ onComplete, initialData }: ScheduleFormProps) {
  const { toast } = useToast();
  const [plantQuantities, setPlantQuantities] = useState<Record<number, number>>({});
  
  const { data: plants = [] } = useQuery({
    queryKey: ["/api/plants"],
  });
  
  const defaultValues = initialData || {
    name: "",
    hour: 9,
    minute: 0,
    ampm: "AM",
    days: ["mon", "wed", "fri"],
    isActive: true,
    selectedPlants: [],
    plantQuantities: []
  };
  
  // Initialize plant quantities if editing
  useState(() => {
    if (initialData?.plantQuantities) {
      const initialQuantities: Record<number, number> = {};
      initialData.plantQuantities.forEach((pq: any) => {
        initialQuantities[pq.plantId] = pq.quantity;
      });
      setPlantQuantities(initialQuantities);
      
      // Set selected plants based on plant quantities
      defaultValues.selectedPlants = initialData.plantQuantities.map((pq: any) => pq.plantId);
    }
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });
  
  const createScheduleMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/schedules", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: "Success",
        description: "Watering schedule created successfully.",
      });
      onComplete();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create schedule: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const updateScheduleMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      const res = await apiRequest("PUT", `/api/schedules/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Success",
        description: "Watering schedule updated successfully.",
      });
      onComplete();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update schedule: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    // Convert selected plants and quantities to the required format
    const formattedPlantQuantities = data.selectedPlants.map(plantId => ({
      plantId,
      quantity: plantQuantities[plantId] || plants.find(p => p.id === plantId)?.waterQuantity || 100
    }));
    
    const scheduleData = {
      ...data,
      plantQuantities: formattedPlantQuantities,
    };
    
    // Remove the selectedPlants field which is just for the form
    delete scheduleData.selectedPlants;
    
    if (initialData?.id) {
      updateScheduleMutation.mutate({ id: initialData.id, data: scheduleData });
    } else {
      createScheduleMutation.mutate(scheduleData);
    }
  };
  
  // Handle time picker changes
  const handleTimeChange = (hour: number, minute: number, ampm: "AM" | "PM") => {
    form.setValue("hour", hour);
    form.setValue("minute", minute);
    form.setValue("ampm", ampm);
  };
  
  // Handle plant quantity changes
  const handleQuantityChange = (plantId: number, quantity: number) => {
    setPlantQuantities(prev => ({
      ...prev,
      [plantId]: quantity
    }));
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Schedule Name</FormLabel>
              <FormControl>
                <Input 
                  placeholder="e.g., Morning Routine" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="hour" // We'll use this to trigger validation, but handle via TimePicker
          render={({ field }) => (
            <FormItem>
              <FormLabel>Watering Time</FormLabel>
              <FormControl>
                <TimePicker
                  hour={form.watch("hour")}
                  minute={form.watch("minute")}
                  ampm={form.watch("ampm") as "AM" | "PM"}
                  onChange={handleTimeChange}
                  className="py-4"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="days"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Days of Week</FormLabel>
              <FormControl>
                <DaySelector
                  selectedDays={field.value}
                  onChange={field.onChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="selectedPlants"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Select Plants and Water Quantity</FormLabel>
              <ScrollArea className="h-60 pr-4">
                <div className="space-y-3">
                  {plants.map(plant => (
                    <div key={plant.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                      <div className="flex items-center">
                        <Checkbox
                          checked={field.value.includes(plant.id)}
                          onCheckedChange={(checked) => {
                            const selectedPlants = checked 
                              ? [...field.value, plant.id]
                              : field.value.filter(id => id !== plant.id);
                            field.onChange(selectedPlants);
                            
                            // Initialize quantity when selecting a plant
                            if (checked && !plantQuantities[plant.id]) {
                              handleQuantityChange(plant.id, plant.waterQuantity);
                            }
                          }}
                          id={`plant-${plant.id}`}
                        />
                        <label htmlFor={`plant-${plant.id}`} className="ml-2 text-sm font-medium">
                          {plant.name}
                        </label>
                      </div>
                      
                      <QuantityInput
                        value={plantQuantities[plant.id] || plant.waterQuantity}
                        onChange={(value) => handleQuantityChange(plant.id, value)}
                        min={10}
                        max={500}
                        step={10}
                      />
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-end space-x-3 pt-2">
          <Button variant="outline" type="button" onClick={onComplete}>
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={createScheduleMutation.isPending || updateScheduleMutation.isPending}
          >
            {createScheduleMutation.isPending || updateScheduleMutation.isPending ? (
              <>
                <span className="material-icons animate-spin mr-2">refresh</span>
                Saving...
              </>
            ) : initialData?.id ? "Update Schedule" : "Save Schedule"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
