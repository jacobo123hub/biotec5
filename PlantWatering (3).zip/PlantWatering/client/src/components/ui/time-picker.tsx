import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface TimePickerProps {
  hour: number;
  minute: number;
  ampm: "AM" | "PM";
  onChange: (hour: number, minute: number, ampm: "AM" | "PM") => void;
  className?: string;
}

export function TimePicker({ hour, minute, ampm, onChange, className }: TimePickerProps) {
  const [isAdjustingHour, setIsAdjustingHour] = useState(true);
  const dialRef = useRef<HTMLDivElement>(null);
  
  // Calculate angles for hands
  const hourAngle = ((hour % 12) / 12) * 360;
  const minuteAngle = (minute / 60) * 360;
  
  const handleDialClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!dialRef.current) return;
    
    const rect = dialRef.current.getBoundingClientRect();
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const x = e.clientX - rect.left - centerX;
    const y = e.clientY - rect.top - centerY;
    
    // Calculate angle from center (0 degrees at top, clockwise)
    let angle = Math.atan2(y, x) * (180 / Math.PI) + 90;
    if (angle < 0) angle += 360;
    
    if (isAdjustingHour) {
      // Convert angle to 12-hour format (0-11)
      const newHour = Math.round(angle / 30) % 12;
      onChange(ampm === "PM" && newHour < 12 ? newHour + 12 : newHour, minute, ampm);
    } else {
      // Convert angle to minutes (0-55, in steps of 5)
      const newMinute = Math.round(angle / 6) * 5 % 60;
      onChange(hour, newMinute, ampm);
    }
  };
  
  const toggleAmPm = () => {
    const newAmPm = ampm === "AM" ? "PM" : "AM";
    let newHour = hour;
    
    // Adjust hour based on AM/PM change
    if (newAmPm === "PM" && hour < 12) {
      newHour += 12;
    } else if (newAmPm === "AM" && hour >= 12) {
      newHour -= 12;
    }
    
    onChange(newHour, minute, newAmPm);
  };
  
  // Click handler for direct hour/minute input
  const handleTimeClick = (type: 'hour' | 'minute') => {
    setIsAdjustingHour(type === 'hour');
  };
  
  // Generate hour markers
  const hourMarkers = Array.from({ length: 12 }).map((_, i) => {
    const angle = (i * 30) - 90; // -90 to start from top
    const isQuarterHour = i % 3 === 0;
    const markerStyle = {
      transform: `rotate(${angle}deg) translateX(100px)`,
      height: isQuarterHour ? '10px' : '5px',
      width: isQuarterHour ? '4px' : '2px',
    };
    
    return <span key={i} className="absolute bg-gray-400" style={markerStyle} />;
  });
  
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div 
        ref={dialRef}
        className="w-60 h-60 rounded-full bg-gray-100 relative mb-4 cursor-pointer shadow-md"
        onClick={handleDialClick}
      >
        {/* Hour markers */}
        <div className="w-full h-full rounded-full absolute top-0 left-0 flex items-center justify-center">
          {hourMarkers}
        </div>
        
        {/* Hour hand */}
        <div 
          className="w-1.5 h-20 bg-primary absolute top-1/2 left-1/2 rounded-full z-10"
          style={{ 
            transformOrigin: 'bottom center', 
            transform: `translate(-50%, -100%) rotate(${hourAngle}deg)` 
          }}
        />
        
        {/* Minute hand */}
        <div 
          className="w-1.5 h-24 bg-blue-500 absolute top-1/2 left-1/2 rounded-full z-5"
          style={{ 
            transformOrigin: 'bottom center', 
            transform: `translate(-50%, -100%) rotate(${minuteAngle}deg)` 
          }}
        />
        
        {/* Center dot */}
        <div className="w-3 h-3 bg-gray-700 rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20" />
      </div>
      
      <div className="flex items-center text-2xl font-medium">
        <span 
          className={cn("cursor-pointer", isAdjustingHour ? "text-primary" : "text-gray-700")}
          onClick={() => handleTimeClick('hour')}
        >
          {(hour % 12 === 0 ? 12 : hour % 12).toString().padStart(2, '0')}
        </span>
        <span className="mx-1">:</span>
        <span 
          className={cn("cursor-pointer", !isAdjustingHour ? "text-primary" : "text-gray-700")}
          onClick={() => handleTimeClick('minute')}
        >
          {minute.toString().padStart(2, '0')}
        </span>
        <span 
          className="ml-2 text-gray-500 cursor-pointer hover:text-primary"
          onClick={toggleAmPm}
        >
          {ampm}
        </span>
      </div>
      
      <div className="flex justify-center mt-2 space-x-2 text-xs text-gray-500">
        <span className={cn("cursor-pointer", isAdjustingHour ? "text-primary font-medium" : "")}
              onClick={() => setIsAdjustingHour(true)}>
          Adjust Hours
        </span>
        <span>•</span>
        <span className={cn("cursor-pointer", !isAdjustingHour ? "text-primary font-medium" : "")}
              onClick={() => setIsAdjustingHour(false)}>
          Adjust Minutes
        </span>
      </div>
    </div>
  );
}
