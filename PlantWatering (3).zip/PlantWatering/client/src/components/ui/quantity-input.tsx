import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface QuantityInputProps {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
  className?: string;
}

export function QuantityInput({
  value,
  min = 0,
  max = 1000,
  step = 10,
  unit = "ml",
  onChange,
  className
}: QuantityInputProps) {
  const handleIncrement = () => {
    const newValue = Math.min(value + step, max);
    onChange(newValue);
  };
  
  const handleDecrement = () => {
    const newValue = Math.max(value - step, min);
    onChange(newValue);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = parseInt(e.target.value, 10);
    if (!isNaN(inputValue)) {
      const newValue = Math.max(min, Math.min(inputValue, max));
      onChange(newValue);
    }
  };
  
  return (
    <div className={cn("flex items-center", className)}>
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 w-8 rounded-l-lg flex items-center justify-center p-0 border"
        onClick={handleDecrement}
      >
        <span className="material-icons text-sm">remove</span>
      </Button>
      
      <Input
        type="number"
        value={value}
        onChange={handleInputChange}
        className="w-16 h-8 text-center rounded-none border-x-0"
        min={min}
        max={max}
        step={step}
      />
      
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 w-8 rounded-r-lg flex items-center justify-center p-0 border"
        onClick={handleIncrement}
      >
        <span className="material-icons text-sm">add</span>
      </Button>
      
      <span className="ml-2 text-sm text-gray-500">{unit}</span>
    </div>
  );
}
