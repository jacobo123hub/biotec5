import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { weekdays } from "@/lib/utils";

interface DaySelectorProps {
  selectedDays: string[];
  onChange: (days: string[]) => void;
  className?: string;
}

export function DaySelector({ selectedDays, onChange, className }: DaySelectorProps) {
  const toggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      onChange(selectedDays.filter(d => d !== day));
    } else {
      onChange([...selectedDays, day]);
    }
  };
  
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {weekdays.map(day => (
        <Button
          key={day.value}
          type="button"
          variant={selectedDays.includes(day.value) ? "default" : "outline"}
          className={cn(
            "flex-1 py-2 text-sm font-medium",
            selectedDays.includes(day.value) 
              ? "bg-primary text-white" 
              : "border-gray-300 text-gray-700 hover:bg-gray-100"
          )}
          onClick={() => toggleDay(day.value)}
        >
          {day.label}
        </Button>
      ))}
    </div>
  );
}
