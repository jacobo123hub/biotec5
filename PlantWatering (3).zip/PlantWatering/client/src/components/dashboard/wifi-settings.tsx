import { useState } from "react";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Wifi, Info, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function WiFiSettings() {
  const queryClient = useQueryClient();
  const [syncingSchedules, setSyncingSchedules] = useState(false);
  
  // Obtener el microcontrolador (asumimos que solo hay uno por ahora)
  const { data: microcontrollers = [] } = useQuery<any[]>({
    queryKey: ['/api/microcontrollers'],
    staleTime: 10000,
  });
  
  const microcontroller = microcontrollers[0];
  
  // Función para sincronizar horarios manualmente
  const syncSchedules = async () => {
    if (!microcontroller) return;
    
    setSyncingSchedules(true);
    try {
      const response = await fetch(`/api/microcontrollers/${microcontroller.id}/wifi/schedules`);
      const result = await response.json();
      
      // Asumimos que result tiene una propiedad schedules que es un array
      const scheduleCount = result?.schedules?.length || 0;
      
      toast({
        title: "¡Éxito!",
        description: `Se sincronizaron ${scheduleCount} horarios al ESP32`,
      });
      
      // Invalidar consultas para mostrar datos actualizados
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/microcontrollers'] });
    } catch (error) {
      toast({
        title: "Error de sincronización",
        description: "No se pudieron sincronizar los horarios al ESP32. Verifica que esté conectado a WiFi.",
        variant: "destructive",
      });
    } finally {
      setSyncingSchedules(false);
    }
  };
  
  // Función para mostrar el estado de conexión
  const getConnectionStatus = () => {
    if (!microcontroller) return { label: "Desconocido", color: "default" };
    
    if (microcontroller.status === "online") {
      return { label: "Conectado", color: "success" };
    } else {
      return { label: "Desconectado", color: "destructive" };
    }
  };
  
  const connectionStatus = getConnectionStatus();
  
  // Calcular tiempo desde la última conexión
  const getLastConnectionTime = () => {
    if (!microcontroller || !microcontroller.lastConnection) return "Nunca conectado";
    
    const lastConnection = new Date(microcontroller.lastConnection);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - lastConnection.getTime()) / (1000 * 60));
    
    if (diffMinutes < 1) return "Justo ahora";
    if (diffMinutes < 60) return `Hace ${diffMinutes} minutos`;
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `Hace ${diffHours} horas`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `Hace ${diffDays} días`;
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wifi className="h-5 w-5" />
          Conexión WiFi ESP32
        </CardTitle>
        <CardDescription>
          Configura y monitorea la comunicación WiFi con tu microcontrolador
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="grid gap-4">
          <div className="flex items-center justify-between">
            <span className="font-medium">Estado de conexión:</span>
            <Badge variant={connectionStatus.color as any}>
              {connectionStatus.label}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="font-medium">Última conexión:</span>
            <span>{getLastConnectionTime()}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="font-medium">Modo de operación:</span>
            <Badge variant={microcontroller?.isAutomatic ? "default" : "outline"}>
              {microcontroller?.isAutomatic ? "Automático" : "Manual"}
            </Badge>
          </div>
          
          <Separator className="my-2" />
          
          <div className="bg-muted/50 p-3 rounded-md">
            <div className="flex items-start gap-2 text-sm">
              <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Información de conexión WiFi</p>
                <p className="mt-1">Tu ESP32 debe estar configurado con los siguientes datos para conectarse a esta aplicación:</p>
                <ul className="list-disc pl-4 mt-2 space-y-1">
                  <li><span className="font-medium">URL de sincronización:</span> /api/microcontrollers/1/wifi/schedules</li>
                  <li><span className="font-medium">URL de estado:</span> /api/microcontrollers/1/wifi/status</li>
                  <li><span className="font-medium">URL para enviar datos:</span> /api/microcontrollers/1/wifi/sensor-data</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => {
            queryClient.invalidateQueries({ queryKey: ['/api/microcontrollers'] });
            toast({
              title: "Actualizado",
              description: "Estado de conexión actualizado",
            });
          }}
        >
          Actualizar estado
        </Button>
        
        <Button onClick={syncSchedules} disabled={syncingSchedules}>
          {syncingSchedules ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Sincronizando...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Sincronizar horarios
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}