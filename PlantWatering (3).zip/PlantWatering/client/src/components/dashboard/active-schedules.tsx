import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Schedule, Plant } from "@shared/schema";
import { formatDays } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ScheduleForm from "@/components/schedules/schedule-form";
import { formatTime } from "@/lib/utils";

export default function ActiveSchedules() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const { data: schedules = [], isLoading: isLoadingSchedules } = useQuery<Schedule[]>({
    queryKey: ["/api/schedules"],
  });
  
  const { data: plants = [] } = useQuery<Plant[]>({
    queryKey: ["/api/plants"],
  });
  
  const toggleScheduleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const res = await apiRequest("PUT", `/api/schedules/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    }
  });
  
  const getPlantNameById = (id: number) => {
    const plant = plants.find(p => p.id === id);
    return plant?.name || "Unknown Plant";
  };
  
  const handleToggleSchedule = (id: number, isActive: boolean) => {
    toggleScheduleMutation.mutate({ id, isActive: !isActive });
  };
  
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Active Schedules</h3>
        <button 
          className="bg-primary text-white px-4 py-2 rounded-lg text-sm flex items-center"
          onClick={() => setIsDialogOpen(true)}
        >
          <span className="material-icons text-sm mr-1">add</span> Add New
        </button>
      </div>
      
      {isLoadingSchedules ? (
        <div className="flex justify-center items-center p-12">
          <span className="material-icons animate-spin mr-2">refresh</span>
          <span>Loading schedules...</span>
        </div>
      ) : schedules.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-4">
          {schedules.map(schedule => (
            <div key={schedule.id} className="bg-white rounded-lg shadow p-4">
              <div className="flex justify-between mb-3">
                <h4 className="font-medium">{schedule.name}</h4>
                <Switch 
                  checked={schedule.isActive} 
                  onCheckedChange={() => handleToggleSchedule(schedule.id, schedule.isActive)}
                />
              </div>
              
              <div className="grid grid-cols-3 mb-3">
                <div>
                  <p className="text-gray-500 text-xs">Time</p>
                  <p className="text-sm font-medium">
                    {formatTime(schedule.hour, schedule.minute, schedule.ampm as 'AM' | 'PM')}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs">Days</p>
                  <p className="text-sm font-medium">
                    {formatDays(schedule.days)}
                  </p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs">Plants</p>
                  <p className="text-sm font-medium">
                    {schedule.plantQuantities.length} plants
                  </p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {schedule.plantQuantities.map(pq => (
                  <span 
                    key={pq.plantId} 
                    className="text-xs bg-primary bg-opacity-10 text-primary-dark px-2 py-1 rounded-full"
                  >
                    {getPlantNameById(pq.plantId)} ({pq.quantity}ml)
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <p className="text-gray-500 mb-4">No schedules found</p>
          <button 
            className="bg-primary text-white px-4 py-2 rounded-lg text-sm inline-flex items-center"
            onClick={() => setIsDialogOpen(true)}
          >
            <span className="material-icons text-sm mr-1">add</span> Create Your First Schedule
          </button>
        </div>
      )}
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Watering Schedule</DialogTitle>
          </DialogHeader>
          <ScheduleForm onComplete={() => setIsDialogOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
