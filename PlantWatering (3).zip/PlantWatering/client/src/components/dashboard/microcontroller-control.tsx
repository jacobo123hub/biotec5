import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Microcontroller } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export default function MicrocontrollerControl() {
  const { toast } = useToast();
  const [serialPort, setSerialPort] = useState<SerialPort | null>(null);
  const [pumpDuration, setPumpDuration] = useState<number>(0);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [scheduleTime, setScheduleTime] = useState<string>("12:00");
  const [scheduleDuration, setScheduleDuration] = useState<number>(5);

  const connectBluetooth = async () => {
    try {
      // Verificar si el navegador soporta Bluetooth
      if (!navigator.bluetooth) {
        throw new Error("Bluetooth no está soportado en este navegador");
      }

      toast({
        title: "Buscando",
        description: "Buscando dispositivo BIOTEC...",
      });

      const device = await navigator.bluetooth.requestDevice({
        filters: [{ name: "BIOTEC" }],
        optionalServices: ['0000ffe0-0000-1000-8000-00805f9b34fb']
      });

      if (!device) {
        throw new Error("No se encontró el dispositivo BIOTEC");
      }

      toast({
        title: "Encontrado",
        description: "Conectando a BIOTEC...",
      });

      const server = await device.gatt?.connect();
      if (!server) {
        throw new Error("No se pudo conectar al dispositivo");
      }

      const service = await server.getPrimaryService('0000ffe0-0000-1000-8000-00805f9b34fb');
      if (!service) {
        throw new Error("Servicio Bluetooth no encontrado");
      }

      const characteristic = await service.getCharacteristic('0000ffe1-0000-1000-8000-00805f9b34fb');
      if (!characteristic) {
        throw new Error("Característica Bluetooth no encontrada");
      }

      setSerialPort(characteristic);
      toast({
        title: "Conectado",
        description: "Dispositivo Bluetooth conectado exitosamente",
      });
    } catch (err) {
      console.error(err);
      toast({
        title: "Error",
        description: "No se pudo conectar al dispositivo. Asegúrate que el Bluetooth esté activado.",
        variant: "destructive",
      });
    }
  };

  const disconnectBluetooth = async () => {
    if (serialPort) {
      await serialPort.close();
      setSerialPort(null);
      toast({
        title: "Desconectado",
        description: "Dispositivo Bluetooth desconectado",
      });
    }
  };
  
  const { data: sensorData } = useQuery({
    queryKey: ["sensor-data"],
    queryFn: async () => {
      const response = await fetch("/api/microcontrollers/1/sensor-data");
      return response.json();
    },
    refetchInterval: 5000
  });

  const currentHumidity = sensorData?.length > 0 ? sensorData[sensorData.length - 1].humidity : null;
  
  const { data: microcontrollers = [], isLoading } = useQuery<Microcontroller[]>({
    queryKey: ["/api/microcontrollers"],
  });
  
  // Tomamos el primer microcontrolador para simplificar (generalmente solo habrá uno)
  const microcontroller = microcontrollers[0];
  
  const toggleMutation = useMutation({
    mutationFn: async ({ id, isAutomatic }: { id: number, isAutomatic: boolean }) => {
      const res = await apiRequest("POST", `/api/microcontrollers/${id}/toggle-auto`, { isAutomatic });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/microcontrollers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      toast({
        title: data.message,
        description: "El modo del microcontrolador ha sido actualizado.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `No se pudo actualizar el microcontrolador: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PUT", `/api/microcontrollers/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/microcontrollers"] });
      toast({
        title: "Estado Actualizado",
        description: "El estado del microcontrolador ha sido actualizado.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `No se pudo actualizar el estado: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const handleToggleAutomaticMode = () => {
    if (!microcontroller) return;
    
    toggleMutation.mutate({ 
      id: microcontroller.id, 
      isAutomatic: !microcontroller.isAutomatic 
    });
  };
  
  const handleReconnect = () => {
    if (!microcontroller) return;
    
    updateStatusMutation.mutate({
      id: microcontroller.id,
      status: "online"
    });
  };
  
  const getStatusBadge = (status: string) => {
    const statusStyles = {
      online: "bg-green-100 text-green-800",
      offline: "bg-gray-100 text-gray-800",
      error: "bg-red-100 text-red-800"
    };
    
    const statusText = {
      online: "Conectado",
      offline: "Desconectado",
      error: "Error"
    };
    
    return (
      <Badge className={statusStyles[status as keyof typeof statusStyles]}>
        {statusText[status as keyof typeof statusText]}
      </Badge>
    );
  };
  
  const getLastConnected = (date: Date | null) => {
    if (!date) return "No disponible";
    
    return new Date(date).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  if (isLoading) {
    return (
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Controlador de Riego</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center p-4">
            <span className="material-icons animate-spin mr-2">refresh</span>
            <span>Cargando información del microcontrolador...</span>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!microcontroller) {
    return (
      <Card className="mb-6">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Controlador de Riego</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center p-4">
            <p className="text-gray-500 mb-4">No hay dispositivos de riego conectados</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="mb-6">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Controlador de Riego</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium">{microcontroller.name}</h3>
              <div className="flex items-center mt-1">
                {getStatusBadge(microcontroller.status)}
                <span className="text-xs text-gray-500 ml-2">
                  Última conexión: {getLastConnected(microcontroller.lastConnection)}
                </span>
              </div>
            </div>
            
            {microcontroller.status === "offline" && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleReconnect}
                disabled={updateStatusMutation.isPending}
              >
                <span className="material-icons text-sm mr-1">sync</span>
                Reconectar
              </Button>
            )}
          </div>
          
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Modo Automático</h4>
                <p className="text-sm text-gray-500">
                  {microcontroller.isAutomatic 
                    ? "El riego se realizará automáticamente según los horarios programados" 
                    : "El riego requiere activación manual"}
                </p>
              </div>
              <Switch
                checked={microcontroller.isAutomatic}
                onCheckedChange={handleToggleAutomaticMode}
                disabled={toggleMutation.isPending || microcontroller.status !== "online"}
              />
            </div>
          </div>
          
          <div className="border-t pt-4">
            <div className="space-y-4">
              <div className="flex items-center gap-4 justify-between">
                <div className="flex-1">
                  <h4 className="font-medium mb-2">Humedad Actual</h4>
                  <div className="bg-blue-50 p-4 rounded-lg flex items-center">
                    <span className="material-icons text-blue-500 mr-2">water_drop</span>
                    <span className="text-2xl font-bold">{currentHumidity ? `${currentHumidity}%` : 'N/A'}</span>
                  </div>
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium mb-2">Control Manual</h4>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="1"
                      max="300"
                      className="w-24 px-2 py-1 border rounded"
                      placeholder="Segundos"
                      value={pumpDuration}
                      onChange={(e) => setPumpDuration(parseInt(e.target.value))}
                    />
                    <Button onClick={() => {
                      if (pumpDuration > 0) {
                        fetch(`/api/microcontrollers/1/pump`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ duration: pumpDuration })
                        });
                      }
                    }}>
                      Activar Bomba
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Programación Automática</h4>
                <Button onClick={() => setScheduleDialogOpen(true)}>
                  Configurar Horario
                </Button>
              </div>

              <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Configurar Riego Automático</DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block mb-2">Hora de Riego</label>
                      <input
                        type="time"
                        className="w-full border rounded px-2 py-1"
                        value={scheduleTime}
                        onChange={(e) => setScheduleTime(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label className="block mb-2">Días de la Semana</label>
                      <div className="flex flex-wrap gap-2">
                        {['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom'].map((day) => (
                          <Button
                            key={day}
                            variant={selectedDays.includes(day) ? "default" : "outline"}
                            onClick={() => {
                              setSelectedDays(prev => 
                                prev.includes(day) 
                                  ? prev.filter(d => d !== day)
                                  : [...prev, day]
                              );
                            }}
                          >
                            {day}
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="block mb-2">Duración del Riego (segundos)</label>
                      <input
                        type="number"
                        min="1"
                        max="300"
                        className="w-full border rounded px-2 py-1"
                        value={scheduleDuration}
                        onChange={(e) => setScheduleDuration(parseInt(e.target.value))}
                      />
                    </div>
                    
                    <Button className="w-full" onClick={() => {
                      fetch('/api/schedules', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          time: scheduleTime,
                          days: selectedDays,
                          duration: scheduleDuration
                        })
                      });
                      setScheduleDialogOpen(false);
                    }}>
                      Guardar Programación
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              <div>
                <h4 className="font-medium">Control Manual de Bomba</h4>
                <div className="flex items-center gap-4 mt-2">
                  <input
                    type="number"
                    min="1"
                    max="300"
                    className="w-24 px-2 py-1 border rounded"
                    placeholder="Segundos"
                    onChange={(e) => setPumpDuration(parseInt(e.target.value))}
                  />
                  <Button 
                    onClick={() => {
                      if (pumpDuration && pumpDuration > 0) {
                        fetch(`/api/microcontrollers/${microcontroller.id}/pump`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ duration: pumpDuration })
                        })
                        .then(res => res.json())
                        .then(data => {
                          toast({
                            title: "Bomba Activada",
                            description: data.message
                          });
                        });
                      }
                    }}
                    disabled={!pumpDuration || pumpDuration <= 0 || microcontroller.status !== "online"}
                  >
                    Activar Bomba
                  </Button>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Ajusta el tiempo de operación de la bomba (1-300 segundos)
                </p>
              </div>
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Información del Dispositivo</h4>
                <p className="text-sm text-gray-500">
                  Dirección IP: {microcontroller.ipAddress || "No disponible"}
                </p>
                <p className="text-sm text-gray-500">
                  Puerto: {microcontroller.port || "No disponible"}
                </p>
                <div className="mt-4 flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={connectBluetooth}
                    disabled={!!serialPort}
                  >
                    Conectar Bluetooth
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={disconnectBluetooth}
                    disabled={!serialPort}
                  >
                    Desconectar Bluetooth
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}