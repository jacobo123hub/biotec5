import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";

export default function RecentActivity() {
  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });
  
  // Limit to recent activities (max 5)
  const recentActivities = activities.slice(0, 5);

  // Helper function to format date
  const formatDate = (timestamp: Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isYesterday = new Date(now.setDate(now.getDate() - 1)).toDateString() === date.toDateString();
    
    const time = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    
    if (isToday) {
      return `Today, ${time}`;
    } else if (isYesterday) {
      return `Yesterday, ${time}`;
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ', ' + time;
    }
  };
  
  // Get icon based on activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'watered':
        return <span className="material-icons text-success mr-3">check_circle</span>;
      case 'warning':
        return <span className="material-icons text-warning mr-3">warning</span>;
      case 'error':
        return <span className="material-icons text-error mr-3">error</span>;
      default:
        return <span className="material-icons text-gray-400 mr-3">info</span>;
    }
  };
  
  // Format activity details
  const getActivityDetails = (activity: Activity) => {
    if (activity.quantity) {
      return `${formatDate(activity.timestamp)} • ${activity.quantity}ml`;
    }
    return formatDate(activity.timestamp);
  };
  
  return (
    <div className="bg-white rounded-lg shadow p-4 mb-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Recent Activity</h3>
        <button className="text-primary text-sm font-medium">View All</button>
      </div>
      
      <div className="space-y-3">
        {isLoading ? (
          <div className="p-8 text-center">
            <span className="material-icons animate-spin">refresh</span>
            <p className="mt-2 text-sm text-gray-500">Loading activities...</p>
          </div>
        ) : recentActivities.length > 0 ? (
          recentActivities.map((activity, index) => (
            <div 
              key={activity.id} 
              className={`flex items-center p-2 ${
                index < recentActivities.length - 1 ? 'border-b border-gray-100' : ''
              }`}
            >
              {getActivityIcon(activity.type)}
              <div>
                <p className="text-sm font-medium">{activity.message}</p>
                <p className="text-xs text-gray-500">{getActivityDetails(activity)}</p>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center p-4 text-gray-500">
            No recent activities
          </div>
        )}
      </div>
    </div>
  );
}
