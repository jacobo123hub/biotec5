import { useQuery } from "@tanstack/react-query";
import { calculateNextWatering, calculateWaterUsedToday } from "@/lib/utils";
import { Activity, Schedule } from "@shared/schema";

export default function Stats() {
  const { data: plants = [] } = useQuery({
    queryKey: ["/api/plants"],
  });
  
  const { data: schedules = [] } = useQuery({
    queryKey: ["/api/schedules"],
  });
  
  const { data: activities = [] } = useQuery({
    queryKey: ["/api/activities"],
  });
  
  const activeSchedules = (schedules as Schedule[]).filter(schedule => schedule.isActive);
  const nextWatering = calculateNextWatering(schedules as Schedule[]);
  const waterUsedToday = calculateWaterUsedToday(activities as Activity[]);
  
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Plants</p>
            <p className="text-2xl font-semibold">{plants.length}</p>
          </div>
          <span className="material-icons text-primary text-3xl">grass</span>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Active Schedules</p>
            <p className="text-2xl font-semibold">{activeSchedules.length}</p>
          </div>
          <span className="material-icons text-blue-400 text-3xl">schedule</span>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Next Watering</p>
            <p className="text-2xl font-semibold">{nextWatering}</p>
          </div>
          <span className="material-icons text-amber-400 text-3xl">access_time</span>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Water Used Today</p>
            <p className="text-2xl font-semibold">{waterUsedToday}</p>
          </div>
          <span className="material-icons text-blue-500 text-3xl">water_drop</span>
        </div>
      </div>
    </div>
  );
}
