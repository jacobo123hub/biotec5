import { useQuery } from "@tanstack/react-query";
import { Plant } from "@shared/schema";
import { useLocation } from "wouter";

export default function PlantsOverview() {
  const { data: plants = [], isLoading } = useQuery<Plant[]>({
    queryKey: ["/api/plants"],
  });
  
  const { data: schedules = [] } = useQuery({
    queryKey: ["/api/schedules"],
  });
  
  const [, navigate] = useLocation();
  
  // Get watering schedule info for a plant
  const getWateringInfo = (plantId: number) => {
    // Find all schedules that include this plant
    const plantSchedules = schedules.filter(schedule => 
      schedule.plantQuantities.some(pq => pq.plantId === plantId)
    );
    
    if (plantSchedules.length === 0) {
      return "No watering schedule";
    }
    
    // Get the first schedule for simplicity
    const firstSchedule = plantSchedules[0];
    const plantQuantity = firstSchedule.plantQuantities.find(pq => pq.plantId === plantId);
    
    const quantity = plantQuantity ? plantQuantity.quantity : 0;
    const days = firstSchedule.days.length > 0 ? firstSchedule.days : ["none"];
    
    return `${quantity}ml every ${days.join(", ")}`;
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">My Plants</h3>
        <button 
          className="text-primary text-sm font-medium flex items-center"
          onClick={() => navigate("/plants")}
        >
          View All
          <span className="material-icons text-sm ml-1">arrow_forward</span>
        </button>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center p-12">
          <span className="material-icons animate-spin mr-2">refresh</span>
          <span>Loading plants...</span>
        </div>
      ) : plants.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {plants.slice(0, 4).map(plant => (
            <div key={plant.id} className="bg-white rounded-lg shadow overflow-hidden">
              <div className="h-32 bg-gray-200 relative">
                <img 
                  src={plant.imageUrl} 
                  alt={plant.name} 
                  className="w-full h-full object-cover" 
                />
                <div className="absolute top-2 right-2 bg-white bg-opacity-90 rounded-full p-1">
                  <span className="material-icons text-primary text-sm">opacity</span>
                </div>
              </div>
              <div className="p-3">
                <h4 className="font-medium">{plant.name}</h4>
                <div className="flex items-center text-xs text-gray-500 mt-1">
                  <span className="water-drop"></span>
                  <span>{getWateringInfo(plant.id)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <p className="text-gray-500 mb-4">No plants found</p>
          <button 
            className="bg-primary text-white px-4 py-2 rounded-lg text-sm inline-flex items-center"
            onClick={() => navigate("/plants")}
          >
            <span className="material-icons text-sm mr-1">add</span> Add Your First Plant
          </button>
        </div>
      )}
    </div>
  );
}
