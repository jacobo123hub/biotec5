import express, { type Request, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertPlantSchema, 
  insertScheduleSchema, 
  insertActivitySchema,
  insertMicrocontrollerSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Plants API Routes
  apiRouter.get("/plants", async (_req: Request, res: Response) => {
    try {
      const plants = await storage.getAllPlants();
      res.json(plants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plants" });
    }
  });
  
  apiRouter.get("/plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid plant ID" });
      }
      
      const plant = await storage.getPlant(id);
      if (!plant) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      res.json(plant);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch plant" });
    }
  });
  
  apiRouter.post("/plants", async (req: Request, res: Response) => {
    try {
      const validation = insertPlantSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid plant data", 
          errors: validation.error.errors 
        });
      }
      
      const plant = await storage.createPlant(validation.data);
      res.status(201).json(plant);
    } catch (error) {
      res.status(500).json({ message: "Failed to create plant" });
    }
  });
  
  apiRouter.put("/plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid plant ID" });
      }
      
      const validation = insertPlantSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid plant data", 
          errors: validation.error.errors 
        });
      }
      
      const plant = await storage.updatePlant(id, validation.data);
      if (!plant) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      res.json(plant);
    } catch (error) {
      res.status(500).json({ message: "Failed to update plant" });
    }
  });
  
  apiRouter.delete("/plants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid plant ID" });
      }
      
      const deleted = await storage.deletePlant(id);
      if (!deleted) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete plant" });
    }
  });
  
  // Schedules API Routes
  apiRouter.get("/schedules", async (_req: Request, res: Response) => {
    try {
      const schedules = await storage.getAllSchedules();
      res.json(schedules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });
  
  apiRouter.get("/schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid schedule ID" });
      }
      
      const schedule = await storage.getSchedule(id);
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedule" });
    }
  });
  
  apiRouter.post("/schedules", async (req: Request, res: Response) => {
    try {
      const validation = insertScheduleSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid schedule data", 
          errors: validation.error.errors 
        });
      }
      
      const schedule = await storage.createSchedule(validation.data);
      res.status(201).json(schedule);
    } catch (error) {
      res.status(500).json({ message: "Failed to create schedule" });
    }
  });
  
  apiRouter.put("/schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid schedule ID" });
      }
      
      const validation = insertScheduleSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid schedule data", 
          errors: validation.error.errors 
        });
      }
      
      const schedule = await storage.updateSchedule(id, validation.data);
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      res.json(schedule);
    } catch (error) {
      res.status(500).json({ message: "Failed to update schedule" });
    }
  });
  
  apiRouter.delete("/schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid schedule ID" });
      }
      
      const deleted = await storage.deleteSchedule(id);
      if (!deleted) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });
  
  // Activities API Routes
  apiRouter.get("/activities", async (_req: Request, res: Response) => {
    try {
      const activities = await storage.getAllActivities();
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });
  
  apiRouter.post("/activities", async (req: Request, res: Response) => {
    try {
      const validation = insertActivitySchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid activity data", 
          errors: validation.error.errors 
        });
      }
      
      const activity = await storage.createActivity(validation.data);
      res.status(201).json(activity);
    } catch (error) {
      res.status(500).json({ message: "Failed to create activity" });
    }
  });
  
  // Mock water now endpoint (simulates immediate watering)
  apiRouter.post("/water-now", async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        plantId: z.number(),
        quantity: z.number().min(1)
      });
      
      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid watering data", 
          errors: validation.error.errors 
        });
      }
      
      const { plantId, quantity } = validation.data;
      
      const plant = await storage.getPlant(plantId);
      if (!plant) {
        return res.status(404).json({ message: "Plant not found" });
      }
      
      // Create a watering activity
      const activity = await storage.createActivity({
        type: 'watered',
        plantId,
        scheduleName: 'Manual Watering',
        quantity,
        message: `${plant.name} watered manually`
      });
      
      res.status(200).json({ 
        success: true, 
        message: `${plant.name} watered with ${quantity}ml`,
        activity
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to water plant" });
    }
  });
  
  // Microcontroller API Routes
  apiRouter.get("/microcontrollers", async (_req: Request, res: Response) => {
    try {
      const microcontrollers = await storage.getAllMicrocontrollers();
      res.json(microcontrollers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch microcontrollers" });
    }
  });
  
  apiRouter.get("/microcontrollers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid microcontroller ID" });
      }
      
      const microcontroller = await storage.getMicrocontroller(id);
      if (!microcontroller) {
        return res.status(404).json({ message: "Microcontroller not found" });
      }
      
      res.json(microcontroller);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch microcontroller" });
    }
  });
  
  apiRouter.post("/microcontrollers", async (req: Request, res: Response) => {
    try {
      const validation = insertMicrocontrollerSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid microcontroller data", 
          errors: validation.error.errors 
        });
      }
      
      const microcontroller = await storage.createMicrocontroller(validation.data);
      res.status(201).json(microcontroller);
    } catch (error) {
      res.status(500).json({ message: "Failed to create microcontroller" });
    }
  });
  
  apiRouter.put("/microcontrollers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid microcontroller ID" });
      }
      
      const validation = insertMicrocontrollerSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid microcontroller data", 
          errors: validation.error.errors 
        });
      }
      
      const microcontroller = await storage.updateMicrocontroller(id, validation.data);
      if (!microcontroller) {
        return res.status(404).json({ message: "Microcontroller not found" });
      }
      
      res.json(microcontroller);
    } catch (error) {
      res.status(500).json({ message: "Failed to update microcontroller" });
    }
  });
  
  apiRouter.delete("/microcontrollers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid microcontroller ID" });
      }
      
      const deleted = await storage.deleteMicrocontroller(id);
      if (!deleted) {
        return res.status(404).json({ message: "Microcontroller not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete microcontroller" });
    }
  });
  
  // Endpoint para cambiar el modo automático del microcontrolador
  // Endpoint para control de bomba con tiempo
  apiRouter.post("/microcontrollers/:id/pump", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }

      const schema = z.object({
        duration: z.number().min(1).max(300), // duración en segundos, máximo 5 minutos
      });

      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Duración inválida" });
      }

      // Aquí enviarías el comando al ESP32
      res.json({ success: true, message: `Bomba activada por ${validation.data.duration} segundos` });
    } catch (error) {
      res.status(500).json({ message: "Error al controlar la bomba" });
    }
  });

  // Endpoint para recibir datos del sensor
  apiRouter.post("/microcontrollers/:id/sensor-data", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }

      const validation = insertSensorDataSchema.safeParse({ ...req.body, microcontrollerId: id });
      if (!validation.success) {
        return res.status(400).json({ message: "Datos del sensor inválidos" });
      }

      // Guardar datos del sensor
      await storage.createSensorData(validation.data);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al guardar datos del sensor" });
    }
  });

  // Rutas para el catálogo de plantas
  apiRouter.get("/plant-catalog", async (_req: Request, res: Response) => {
    try {
      const catalog = await storage.getPlantCatalog();
      res.json(catalog);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener catálogo" });
    }
  });

  apiRouter.post("/plant-catalog", async (req: Request, res: Response) => {
    try {
      const validation = insertPlantCatalogSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Datos de planta inválidos" });
      }

      const plant = await storage.createPlantCatalogEntry(validation.data);
      res.status(201).json(plant);
    } catch (error) {
      res.status(500).json({ message: "Error al crear entrada de catálogo" });
    }
  });

  apiRouter.post("/microcontrollers/:id/toggle-auto", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid microcontroller ID" });
      }
      
      const schema = z.object({
        isAutomatic: z.boolean()
      });
      
      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid data", 
          errors: validation.error.errors 
        });
      }
      
      const { isAutomatic } = validation.data;
      
      const microcontroller = await storage.toggleMicrocontrollerAutoMode(id, isAutomatic);
      if (!microcontroller) {
        return res.status(404).json({ message: "Microcontroller not found" });
      }
      
      // Create a system activity
      await storage.createActivity({
        type: 'system',
        message: `Modo automático ${isAutomatic ? 'activado' : 'desactivado'} para el microcontrolador`,
        plantId: null,
        scheduleName: null,
        quantity: null
      });
      
      res.status(200).json({ 
        success: true, 
        message: `Modo automático ${isAutomatic ? 'activado' : 'desactivado'}`,
        microcontroller
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle automatic mode" });
    }
  });
  
  // Endpoints para comunicación WiFi con ESP32
  
  // Endpoint para que el ESP32 obtenga los horarios de riego
  apiRouter.get("/microcontrollers/:id/wifi/schedules", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }
      
      const microcontroller = await storage.getMicrocontroller(id);
      if (!microcontroller) {
        return res.status(404).json({ message: "Microcontrolador no encontrado" });
      }
      
      // Obtener horarios y configurar formato adecuado para ESP32
      const schedules = await storage.getAllSchedules();
      const activeSchedules = schedules.filter(s => s.isActive);
      
      // Formatear horarios para el microcontrolador
      const formattedSchedules = activeSchedules.map(schedule => {
        // Convertir hora AM/PM a formato 24 horas para ESP32
        let hour24 = schedule.hour;
        if (schedule.ampm === "PM" && schedule.hour < 12) {
          hour24 += 12;
        } else if (schedule.ampm === "AM" && schedule.hour === 12) {
          hour24 = 0;
        }
        
        return {
          id: schedule.id,
          name: schedule.name,
          hour: hour24,
          minute: schedule.minute,
          days: schedule.days,
          plants: schedule.plantQuantities.map(pq => ({
            id: pq.plantId,
            quantity: pq.quantity
          }))
        };
      });
      
      // Actualizar última conexión del microcontrolador
      await storage.updateMicrocontroller(id, {
        status: "online",
        lastConnection: new Date()
      });
      
      // Crear actividad de sistema
      await storage.createActivity({
        type: 'system',
        message: `ESP32 (${microcontroller.name}) sincronizó horarios vía WiFi`,
        plantId: null,
        scheduleName: null,
        quantity: null
      });
      
      res.status(200).json({
        success: true,
        autoMode: microcontroller.isAutomatic,
        schedules: formattedSchedules
      });
    } catch (error) {
      res.status(500).json({ message: "Error al obtener horarios para microcontrolador" });
    }
  });
  
  // Endpoint para que el ESP32 reporte datos de sensores
  apiRouter.post("/microcontrollers/:id/wifi/sensor-data", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }
      
      const schema = z.object({
        moisture: z.number().min(0).max(100).optional(),
        temperature: z.number().optional(),
        waterLevel: z.number().min(0).max(100).optional()
      });
      
      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Datos de sensores inválidos", 
          errors: validation.error.errors 
        });
      }
      
      const sensorData = validation.data;
      
      // Actualizar estado del microcontrolador
      await storage.updateMicrocontroller(id, {
        status: "online",
        lastConnection: new Date()
      });
      
      res.status(200).json({
        success: true,
        data: sensorData,
        timestamp: new Date()
      });
    } catch (error) {
      res.status(500).json({ message: "Error al procesar datos de sensores" });
    }
  });
  
  // Endpoint para reportar actividades de riego desde el ESP32
  apiRouter.post("/microcontrollers/:id/wifi/watering-event", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }
      
      const schema = z.object({
        plantId: z.number(),
        quantity: z.number(),
        scheduleId: z.number().optional(),
        scheduleName: z.string().optional(),
        success: z.boolean().optional()
      });
      
      const validation = schema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Datos de evento de riego inválidos", 
          errors: validation.error.errors 
        });
      }
      
      const { plantId, quantity, scheduleId, scheduleName, success = true } = validation.data;
      
      // Obtener planta
      const plant = await storage.getPlant(plantId);
      if (!plant) {
        return res.status(404).json({ message: "Planta no encontrada" });
      }
      
      // Obtener nombre del horario si se proporcionó un ID
      let scheduleNameToUse = scheduleName || "Riego Automático";
      if (scheduleId && !scheduleName) {
        const schedule = await storage.getSchedule(scheduleId);
        if (schedule) {
          scheduleNameToUse = schedule.name;
        }
      }
      
      // Registrar actividad de riego
      const activity = await storage.createActivity({
        type: success ? 'watered' : 'warning',
        plantId,
        scheduleName: scheduleNameToUse,
        quantity,
        message: success 
          ? `${plant.name} regada automáticamente`
          : `Error al regar ${plant.name}`
      });
      
      // Actualizar última conexión del microcontrolador
      await storage.updateMicrocontroller(id, {
        status: "online",
        lastConnection: new Date()
      });
      
      res.status(200).json({
        success: true,
        activity
      });
    } catch (error) {
      res.status(500).json({ message: "Error al registrar evento de riego" });
    }
  });
  
  // Endpoint para obtener estado del sistema
  apiRouter.get("/microcontrollers/:id/wifi/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID de microcontrolador inválido" });
      }
      
      const microcontroller = await storage.getMicrocontroller(id);
      if (!microcontroller) {
        return res.status(404).json({ message: "Microcontrolador no encontrado" });
      }
      
      // Actualizar última conexión del microcontrolador
      await storage.updateMicrocontroller(id, {
        status: "online",
        lastConnection: new Date()
      });
      
      res.status(200).json({
        success: true,
        isAutomatic: microcontroller.isAutomatic,
        status: microcontroller.status,
        serverTime: new Date()
      });
    } catch (error) {
      res.status(500).json({ message: "Error al obtener estado del sistema" });
    }
  });
  
  // Use API router with prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);

  return httpServer;
}
