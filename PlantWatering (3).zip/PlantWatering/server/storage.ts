import { 
  users, type User, type InsertUser,
  plants, type Plant, type InsertPlant,
  schedules, type Schedule, type InsertSchedule,
  activities, type Activity, type InsertActivity,
  microcontrollers, type Microcontroller, type InsertMicrocontroller
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Plant methods
  getPlant(id: number): Promise<Plant | undefined>;
  getAllPlants(): Promise<Plant[]>;
  createPlant(plant: InsertPlant): Promise<Plant>;
  updatePlant(id: number, plant: Partial<InsertPlant>): Promise<Plant | undefined>;
  deletePlant(id: number): Promise<boolean>;
  
  // Schedule methods
  getSchedule(id: number): Promise<Schedule | undefined>;
  getAllSchedules(): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;
  
  // Activity methods
  getActivity(id: number): Promise<Activity | undefined>;
  getAllActivities(): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Microcontroller methods
  getMicrocontroller(id: number): Promise<Microcontroller | undefined>;
  getAllMicrocontrollers(): Promise<Microcontroller[]>;
  createMicrocontroller(microcontroller: InsertMicrocontroller): Promise<Microcontroller>;
  updateMicrocontroller(id: number, microcontroller: Partial<InsertMicrocontroller>): Promise<Microcontroller | undefined>;
  deleteMicrocontroller(id: number): Promise<boolean>;
  toggleMicrocontrollerAutoMode(id: number, isAutomatic: boolean): Promise<Microcontroller | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private plants: Map<number, Plant>;
  private schedules: Map<number, Schedule>;
  private activities: Map<number, Activity>;
  private microcontrollers: Map<number, Microcontroller>;
  
  private userId: number;
  private plantId: number;
  private scheduleId: number;
  private activityId: number;
  private microcontrollerId: number;

  constructor() {
    this.users = new Map();
    this.plants = new Map();
    this.schedules = new Map();
    this.activities = new Map();
    this.microcontrollers = new Map();
    
    this.userId = 1;
    this.plantId = 1;
    this.scheduleId = 1;
    this.activityId = 1;
    this.microcontrollerId = 1;
    
    // Add some initial data
    this.initSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Plant methods
  async getPlant(id: number): Promise<Plant | undefined> {
    return this.plants.get(id);
  }
  
  async getAllPlants(): Promise<Plant[]> {
    return Array.from(this.plants.values());
  }
  
  async createPlant(insertPlant: InsertPlant): Promise<Plant> {
    const id = this.plantId++;
    const plant: Plant = { ...insertPlant, id };
    this.plants.set(id, plant);
    return plant;
  }
  
  async updatePlant(id: number, plantUpdate: Partial<InsertPlant>): Promise<Plant | undefined> {
    const plant = this.plants.get(id);
    if (!plant) return undefined;
    
    const updatedPlant = { ...plant, ...plantUpdate };
    this.plants.set(id, updatedPlant);
    return updatedPlant;
  }
  
  async deletePlant(id: number): Promise<boolean> {
    return this.plants.delete(id);
  }
  
  // Schedule methods
  async getSchedule(id: number): Promise<Schedule | undefined> {
    return this.schedules.get(id);
  }
  
  async getAllSchedules(): Promise<Schedule[]> {
    return Array.from(this.schedules.values());
  }
  
  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const id = this.scheduleId++;
    const schedule: Schedule = { ...insertSchedule, id };
    this.schedules.set(id, schedule);
    
    // Create activity for schedule creation
    this.createActivity({
      type: 'system',
      message: `Schedule "${schedule.name}" created`,
      scheduleName: schedule.name,
      plantId: null,
      quantity: null
    });
    
    return schedule;
  }
  
  async updateSchedule(id: number, scheduleUpdate: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    const schedule = this.schedules.get(id);
    if (!schedule) return undefined;
    
    const updatedSchedule = { ...schedule, ...scheduleUpdate };
    this.schedules.set(id, updatedSchedule);
    
    // Create activity for schedule update
    if (scheduleUpdate.isActive !== undefined && scheduleUpdate.isActive !== schedule.isActive) {
      this.createActivity({
        type: 'system',
        message: `Schedule "${schedule.name}" ${scheduleUpdate.isActive ? 'activated' : 'deactivated'}`,
        scheduleName: schedule.name,
        plantId: null,
        quantity: null
      });
    }
    
    return updatedSchedule;
  }
  
  async deleteSchedule(id: number): Promise<boolean> {
    const schedule = this.schedules.get(id);
    if (schedule) {
      this.createActivity({
        type: 'system',
        message: `Schedule "${schedule.name}" deleted`,
        scheduleName: schedule.name,
        plantId: null,
        quantity: null
      });
    }
    return this.schedules.delete(id);
  }
  
  // Activity methods
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }
  
  async getAllActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values()).sort((a, b) => {
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityId++;
    const timestamp = new Date();
    // Ensure null values for optional fields if they're undefined
    const activity: Activity = {
      ...insertActivity,
      id,
      timestamp,
      plantId: insertActivity.plantId ?? null,
      quantity: insertActivity.quantity ?? null,
      scheduleName: insertActivity.scheduleName ?? null
    };
    this.activities.set(id, activity);
    return activity;
  }
  
  // Microcontroller methods
  async getMicrocontroller(id: number): Promise<Microcontroller | undefined> {
    return this.microcontrollers.get(id);
  }
  
  async getAllMicrocontrollers(): Promise<Microcontroller[]> {
    return Array.from(this.microcontrollers.values());
  }
  
  async createMicrocontroller(insertMicrocontroller: InsertMicrocontroller): Promise<Microcontroller> {
    const id = this.microcontrollerId++;
    const lastConnection = new Date();
    
    // Asegurar valores predeterminados para las propiedades opcionales
    const microcontroller: Microcontroller = {
      id,
      name: insertMicrocontroller.name,
      status: insertMicrocontroller.status || "offline",
      ipAddress: insertMicrocontroller.ipAddress || null,
      port: insertMicrocontroller.port || null,
      isAutomatic: insertMicrocontroller.isAutomatic ?? false,
      lastConnection: lastConnection
    };
    
    this.microcontrollers.set(id, microcontroller);
    
    // Create activity for microcontroller connection
    this.createActivity({
      type: 'system',
      message: `Microcontroller "${microcontroller.name}" connected`,
      plantId: null,
      scheduleName: null,
      quantity: null
    });
    
    return microcontroller;
  }
  
  async updateMicrocontroller(id: number, update: Partial<InsertMicrocontroller>): Promise<Microcontroller | undefined> {
    const microcontroller = this.microcontrollers.get(id);
    if (!microcontroller) return undefined;
    
    const updatedMicrocontroller = { ...microcontroller, ...update };
    this.microcontrollers.set(id, updatedMicrocontroller);
    
    // Create activity for significant updates
    if (update.status && update.status !== microcontroller.status) {
      this.createActivity({
        type: 'system',
        message: `Microcontroller "${microcontroller.name}" status changed to ${update.status}`,
        plantId: null,
        scheduleName: null,
        quantity: null
      });
    }
    
    return updatedMicrocontroller;
  }
  
  async deleteMicrocontroller(id: number): Promise<boolean> {
    const microcontroller = this.microcontrollers.get(id);
    if (microcontroller) {
      this.createActivity({
        type: 'system',
        message: `Microcontroller "${microcontroller.name}" removed`,
        plantId: null,
        scheduleName: null,
        quantity: null
      });
    }
    return this.microcontrollers.delete(id);
  }
  
  async toggleMicrocontrollerAutoMode(id: number, isAutomatic: boolean): Promise<Microcontroller | undefined> {
    const microcontroller = this.microcontrollers.get(id);
    if (!microcontroller) return undefined;
    
    const updatedMicrocontroller = { ...microcontroller, isAutomatic };
    this.microcontrollers.set(id, updatedMicrocontroller);
    
    // Create activity for the automatic mode toggle
    this.createActivity({
      type: 'system',
      message: `Microcontroller "${microcontroller.name}" automatic mode ${isAutomatic ? 'enabled' : 'disabled'}`,
      plantId: null,
      scheduleName: null,
      quantity: null
    });
    
    return updatedMicrocontroller;
  }
  
  // Helper to initialize sample data
  private initSampleData() {
    // Create plants
    const plants = [
      {
        name: "Monstera",
        waterQuantity: 200,
        imageUrl: "https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=300&h=200&fit=crop"
      },
      {
        name: "Basil",
        waterQuantity: 150,
        imageUrl: "https://images.unsplash.com/photo-1520302630591-fd1c66edc19d?w=300&h=200&fit=crop"
      },
      {
        name: "Snake Plant",
        waterQuantity: 100,
        imageUrl: "https://images.unsplash.com/photo-1628796065365-823fa864730e?w=300&h=200&fit=crop"
      },
      {
        name: "Orchid",
        waterQuantity: 120,
        imageUrl: "https://images.unsplash.com/photo-1639886727226-8716837e506f?w=300&h=200&fit=crop"
      }
    ];
    
    plants.forEach(plant => this.createPlant(plant));
    
    // Create schedules
    this.createSchedule({
      name: "Morning Routine",
      hour: 9,
      minute: 0,
      ampm: "AM",
      days: ["mon", "wed", "fri"],
      isActive: true,
      plantQuantities: [
        { plantId: 1, quantity: 200 },
        { plantId: 2, quantity: 150 },
        { plantId: 3, quantity: 180 }
      ]
    });
    
    this.createSchedule({
      name: "Evening Routine",
      hour: 6,
      minute: 30,
      ampm: "PM",
      days: ["tue", "thu", "sat"],
      isActive: true,
      plantQuantities: [
        { plantId: 3, quantity: 100 },
        { plantId: 4, quantity: 120 }
      ]
    });
    
    // Create recent activities
    const now = new Date();
    
    // Today's activities
    this.createActivity({
      type: 'watered',
      plantId: 1,
      scheduleName: "Morning Routine",
      quantity: 200,
      message: "Monstera watered"
    });
    
    this.createActivity({
      type: 'watered',
      plantId: 2,
      scheduleName: "Morning Routine",
      quantity: 150,
      message: "Basil watered"
    });
    
    // Yesterday's activities
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    this.createActivity({
      type: 'warning',
      plantId: null,
      scheduleName: null,
      quantity: null,
      message: "Low water level"
    });
    
    this.activities.get(3)!.timestamp = yesterday;
    
    this.createActivity({
      type: 'watered',
      plantId: 3,
      scheduleName: "Evening Routine",
      quantity: 100,
      message: "Snake Plant watered"
    });
    
    this.activities.get(4)!.timestamp = yesterday;
    
    // Create a sample microcontroller
    this.createMicrocontroller({
      name: "ESP32 Riego Automático",
      status: "online",
      ipAddress: "192.168.1.100",
      port: 8080,
      isAutomatic: false,
      lastConnection: new Date()
    });
  }
}

export const storage = new MemStorage();
